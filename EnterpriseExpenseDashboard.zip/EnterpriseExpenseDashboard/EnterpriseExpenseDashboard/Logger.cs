﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;

namespace EnterpriseExpenseDashboard
{
    public class Logger
    {
        private static string LogFilePath
        {
            get
            {
                return HttpContext.Current.Server.MapPath("~/App_Data/ErrorLog.txt");
            }
        }
        public static void LogError(Exception e)
        {
  
            string msg = $"Date{DateTime.Now}:{e.Message}:StackTrace:{e.StackTrace}";
                File.AppendAllText(LogFilePath, msg);

        }
    }
}