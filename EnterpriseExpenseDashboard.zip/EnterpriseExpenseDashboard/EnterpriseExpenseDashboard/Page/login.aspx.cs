﻿using EnterpriseExpenseDashboard.App_code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EnterpriseExpenseDashboard.Page
{
    public partial class login : System.Web.UI.Page
    {
        private UserManager _usermanager = new UserManager();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUserName.Text.Trim();
                string password = txtpassword.Text.Trim();
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    return;
                }
                if (!Regex.IsMatch(username, @"^[a-zA-Z0-9._]{3,20}$"))
                {
                    lblServerMessage.Text = "Invalid username format.";
                    return;
                }

                if (!Regex.IsMatch(password,
                   @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$"))
                {
                    lblServerMessage.Text = "Password should include  one specialcharacter,lowercase,uppercase and minimum 8 characters";
                    return;
                }

                string passwordhash = _usermanager.HashPassword(password);

                DataTable dt = _usermanager.ValidateUser(username, passwordhash);
                if (dt.Rows.Count > 0)
                {
                    Session["Userid"] = dt.Rows[0]["UserID"];
                    Session["UserName"] = dt.Rows[0]["UserName"];
                    Session["Role"] = dt.Rows[0]["Role"];
                    FormsAuthentication.SetAuthCookie(username, false);
                    Response.Redirect("~/Page/Dashboard.aspx");
                }
                else
                {
                    lblServerMessage.Text = "Invalid username/password";
                }
            }
            catch(Exception ex) 
            {
                Logger.LogError(ex);
                lblServerMessage.Text = "Something went wrong.Please try again";
            }

        }
    }
}