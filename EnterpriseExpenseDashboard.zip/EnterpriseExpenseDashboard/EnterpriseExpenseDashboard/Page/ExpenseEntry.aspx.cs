﻿using EnterpriseExpenseDashboard.code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace EnterpriseExpenseDashboard.Page
{
    public partial class ExpenseEntry : System.Web.UI.Page
    {
        private ExpenseManager expenseManager = new ExpenseManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated || Session["Role"].ToString().ToLower() != "admin")
            {
                Response.Redirect("~/Page/login.aspx");
            }
            if (!IsPostBack)
            {
                BindCategories();
                HideMessage();
                ClearForm();
            }
        }
        protected void btnAddCategory_click(object sender, EventArgs e)
        {
            try
            {
                lblCatMsg.Text = "";
                lblCatMsg.CssClass = "text-danger";
                if (string.IsNullOrEmpty(txtCategory.Text))
                {
                    lblCatMsg.Text = "Category name is required";
                    return;
                }
                expenseManager.InsertCategories(txtCategory.Text);
                BindCategories();
                txtCategory.Text = "";
            }
            catch (Exception )
            {
                lblCatMsg.Text = "Unexpected error at adding category";
            }
           }
        protected void BindCategories()
        {
            try
            {
                DataTable dt = expenseManager.GetCategories();

                ddlCategory.DataSource = dt;
                ddlCategory.DataTextField = "CategoryName";
                ddlCategory.DataValueField = "Categoryid";
                ddlCategory.DataBind();
                ddlCategory.Items.Insert(0, new ListItem("--Select Catgeory--", "0"));
            }
            catch(Exception )
            {
                ShowMessage("Failed to load Categories", false);
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                int userid = Convert.ToInt32(Session["Userid"]);
                int categoryid = Convert.ToInt32(ddlCategory.SelectedValue);
                decimal amount = Convert.ToDecimal(txtAmount.Text.Trim());
                expenseManager.InsertExpense(userid, categoryid, amount);
                ShowMessage("Expense saved Successfully", true);
                ClearForm();
            }
            catch(Exception ex)
            {
                lblExpMsg.Text = "Unable to save categories";
                Logger.LogError(ex);
            }
        }
        private void ClearForm()
        {
            ddlCategory.SelectedIndex = 0;
            txtAmount.Text = string.Empty;
            txtCategory.Text = string.Empty;
            lblClientMessage.Text = string.Empty;
        }
        private void ShowMessage(string msg,bool isSuccess)
        {
            lblClientMessage.Text = msg;
            lblClientMessage.CssClass = isSuccess ? "success-message": "error-message";
            lblClientMessage.Style["display"] = "block";
        }
        private void HideMessage()
        {
            lblCatMsg.Text = "";
            lblExpMsg.Text = string.Empty;
            lblClientMessage.Style["display"] = "none";
            lblClientMessage.Text = string.Empty;
        }

    }
}