﻿using EnterpriseExpenseDashboard.App_code;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EnterpriseExpenseDashboard.Page
{
    public partial class CreateUser : System.Web.UI.Page
    {
        private UserManager _usermanager = new UserManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated || Session["Role"].ToString().ToLower() != "admin")
            {
                Response.Redirect("~/Page/login.aspx");
            }
        }
        protected void btnCreate_Click(object sender,EventArgs e)
        {
            try
            {
                string username = txtUserName.Text.Trim();
                string password = txtpassword.Text.Trim();
                string role = ddlRolelist.SelectedValue;
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    lblServerMessage.Text = "Username and password required";
                    return;
                }
                if (!Regex.IsMatch(username, @"^[a-zA-Z0-9._]{5,20}$"))
                {
                    lblServerMessage.Text = "Invalid username format.";
                    return;
                }

                if (!Regex.IsMatch(password,
                   @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$"))
                {
                    lblServerMessage.Text = "Password should include  one specialcharacter,lowercase,uppercase and minimum 8 characters";
                    return;
                }
                string passwordhash = _usermanager.HashPassword(password);
                _usermanager.CreateUser(username, passwordhash, role);
                lblServerMessage.CssClass = "text-success mt-2 d-block";
                lblServerMessage.Text = "User created Successfully";
            }
            catch (Exception ex)
            {
                lblServerMessage.Text = "Unable to create User";
            }
        }
    }
}