﻿using EnterpriseExpenseDashboard.code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EnterpriseExpenseDashboard.Page
{
    public partial class Dashboard : System.Web.UI.Page
    {
        private ExpenseManager _expenseManager = new ExpenseManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!User.Identity.IsAuthenticated || Session["Role"].ToString().ToLower() != "admin")
            {
                Response.Redirect("~/Page/login.aspx");
            }
            if (!IsPostBack)
            {
                BindGrid();
                BindChart();
            }
        }
        protected void BindGrid()
        {
            gvExpenses.DataSource=_expenseManager.GetExpenses();
            gvExpenses.DataBind();
        }
        protected void BindChart()
        {
            DataTable dt = _expenseManager.GetExpenses();
            var rows = new List<Dictionary<string, object>>();

            foreach (DataRow dr in dt.Rows)
            {
                var row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row[col.ColumnName] = dr[col];
                }
                rows.Add(row);
            }
            JavaScriptSerializer js = new JavaScriptSerializer();
            string json = js.Serialize(rows);
            ClientScript.RegisterStartupScript(this.GetType(), "ExpenseChart", $"renderChart({json});", true);
        }
        protected void gvExpenses_rowEditing(object sender,GridViewEditEventArgs e)
        {
            gvExpenses.EditIndex = e.NewEditIndex;
            BindGrid();
            BindChart();
        }
        protected void gvExpenses_rowCancelEditing(object sender,GridViewCancelEditEventArgs e)
        {
            gvExpenses.EditIndex = -1;
            BindGrid();
            BindChart();
        }
        protected void gvExpenses_rowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int expenseid = Convert.ToInt32(gvExpenses.DataKeys[e.RowIndex].Value);
            GridViewRow row = gvExpenses.Rows[e.RowIndex];
            decimal amount = Convert.ToDecimal(((TextBox)row.Cells[1].Controls[0]).Text);
            _expenseManager.UpdateCategory(expenseid, amount);

            gvExpenses.EditIndex = -1;
            BindGrid();
            BindChart();

        }
        protected void gvExpenses_rowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int expenseid = Convert.ToInt32(gvExpenses.DataKeys[e.RowIndex].Value);
            _expenseManager.DeleteCategory(expenseid);
        }
        protected void btnLogout_click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.RedirectToLoginPage();
        }
    }
}