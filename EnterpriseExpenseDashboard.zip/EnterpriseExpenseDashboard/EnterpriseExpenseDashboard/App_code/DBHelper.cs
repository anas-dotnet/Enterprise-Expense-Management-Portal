﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace EnterpriseExpenseDashboard.App_code
{
    public class DBHelper
    {
        private readonly string connectionstring = ConfigurationManager.ConnectionStrings["sqldb"].ConnectionString;

        public void ExecuteNonQuery(string spName, params SqlParameter[] sqlParams)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand(spName, sqlConn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (sqlParams != null && sqlParams.Length > 0)
                        {
                            cmd.Parameters.AddRange(sqlParams);
                        }
                        sqlConn.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);
            }
        }
        public DataTable ExecuteDataTable(string spName,bool isStoredProcedure,params SqlParameter[] sqlParams)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand(spName, sqlConn))
                    {
                        cmd.CommandType = isStoredProcedure ? CommandType.StoredProcedure : CommandType.Text;
                        if (sqlParams != null && sqlParams.Length > 0)
                        {
                            cmd.Parameters.AddRange(sqlParams);
                        }
                        sqlConn.Open();
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);
            }     
            return dt;
        }
        public object ExecuteScalar(string spName, params SqlParameter[] sqlParams)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand(spName, sqlConn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (sqlParams != null && sqlParams.Length > 0)
                        {
                            cmd.Parameters.AddRange(sqlParams);
                        }
                        sqlConn.Open();
                        return cmd.ExecuteScalar();

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);
            }
            return null;
        }
    }
}