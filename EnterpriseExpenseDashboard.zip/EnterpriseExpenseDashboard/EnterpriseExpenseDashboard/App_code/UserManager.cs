﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.Security;
using System.Web.UI.WebControls;

namespace EnterpriseExpenseDashboard.App_code
{
   
   
    public class UserManager
    {
        private DBHelper _db = new DBHelper();
        public DataTable ValidateUser(string username,string password)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Username",username),
                new SqlParameter("@passwordhash",password)
            };
          return  _db.ExecuteDataTable("sp_LoginUser", true, parameters);
        }
        public void CreateUser(string username,string password,string role)
        {
            SqlParameter[] parameters = new SqlParameter[]
           {
              
                new SqlParameter("@Username",username),
                new SqlParameter("@passwordHash",password),
                new SqlParameter("@Role",role)
           };

            _db.ExecuteDataTable("sp_CreateUser", true, parameters);
        }
        public string HashPassword(string password)
        {
            using(var sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}