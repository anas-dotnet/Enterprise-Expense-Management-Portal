﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using EnterpriseExpenseDashboard.App_code;

namespace EnterpriseExpenseDashboard.code
{
    public class ExpenseManager
    {
        private DBHelper _db = new DBHelper();
        public void InsertExpense(int userid, int categoryId, decimal amount)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserId",userid),
                new SqlParameter("@CategoryId",categoryId),
                new SqlParameter("@Amount",amount)
            };
            _db.ExecuteNonQuery("sp_InsertExpenses", parameters);
        }
        public DataTable GetExpenses()
        {
            return _db.ExecuteDataTable("sp_GetExpenses",true);
        }
        public DataTable GetCategoryWiseExpense()
        {
            return _db.ExecuteDataTable("sp_GetCatgeoryWiseExpnense",true);
        }
        public DataTable GetCategories()
        {
            string query = "select Categoryid,CategoryName from Categories";
            return _db.ExecuteDataTable(query,false);
        }
        public void InsertCategories(string category)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@CategoryName",category),
            };
            _db.ExecuteNonQuery("sp_InsertCategory", parameters);
        }
        public void UpdateCategory(int expenseId,decimal amount)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@ExpenseId",expenseId),
                new SqlParameter("@Amount",amount)
            };
            _db.ExecuteNonQuery("sp_UpdatedExpense", parameters);
        }
        public void DeleteCategory(int expenseId)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@ExpenseId",expenseId)
            };
            _db.ExecuteNonQuery("sp_DeleteExpense", parameters);
        }

    }
}