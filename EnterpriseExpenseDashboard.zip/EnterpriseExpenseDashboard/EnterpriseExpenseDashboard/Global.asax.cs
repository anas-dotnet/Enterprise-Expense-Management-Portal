﻿using EnterpriseExpensePortal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml.Serialization;
using WebGrease.Activities;

namespace EnterpriseExpenseDashboard
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        protected void Application_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            Logger.LogError(ex);
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.RedirectToLoginPage();
        }
        protected void Application_AcquiredRequestState(object sender, EventArgs e)
        {
            var context=HttpContext.Current;
            if (context.Session == null) return;
            string path = context.Request.AppRelativeCurrentExecutionFilePath;
            if (path.StartsWith("~/Page/Dashboard.aspx"))
            {
                if (context.Session["Role"] == null || context.Session["Role"]?.ToString().ToLower() != "admin")
                {
                    context.Response.Redirect("~/Page/login.aspx");
                }
            }
        }
    }
}